from urllib.parse import urlparse
import pickle
model = pickle.load(open("Phishing_website.pkl", 'rb'))
def extract_features(url):
    features = []

    try:
        # Perform basic checks on the URL
        parsed_url = urlparse(url)

        # Check if the URL uses the HTTP or HTTPS protocol
        if parsed_url.scheme not in ["http", "https"]:
            features.append(-1)
        else:
            features.append(1)

        # Check if the hostname is an IP address
        if parsed_url.hostname and parsed_url.hostname.replace(".", "").isdigit():
            features.append(-1)
        else:
            features.append(1)

        # Check if the URL contains certain keywords (modify as needed)
        if "phishing" in parsed_url.netloc.lower() or "fake" in parsed_url.netloc.lower():
            features.append(-1)
        else:
            features.append(1)

        # Add more checks based on your requirements

    except Exception as e:
        features.append(-1)
    
    return features

def predict_phishing(model, features):
    try:
        # Your prediction code here
        prediction = model.predict([features])
        return prediction[0]
    except Exception as e:
        return str(e)
