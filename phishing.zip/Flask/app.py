import numpy as np 
from flask import Flask, request, jsonify, render_template
import pickle
from Script import *
model=pickle.load(open('Phishing_website.pkl','rb'))
app=Flask(__name__)

@app.route("/")
def index():
    return render_template('index.html')

@app.route('/index', methods=['POST','GET'])
def home():
    return render_template('index.html')

@app.route('/about', methods=['POST','GET'])
def about():
    return render_template('about.html')

@app.route('/contact', methods=['POST','GET'])
def contact():
    return render_template('contact.html')

@app.route('/index', methods=['POST','GET'])
def get_started():
    return render_template('index.html')

@app.route("/result", methods=['POST','GET'])
def result():
    error_message = None  # Initialize the error message as None

    if request.method == "POST":
        url = request.form["url"]

        # Check if the URL is empty or doesn't start with http:// or https://
        if not url:
            error_message = "Please provide a URL."
            return render_template("result.html", result_text=error_message)
        elif not (url.startswith("http://") or url.startswith("https://")):
            error_message = "Please provide a valid URL starting with http:// or https://"
            return render_template("result.html", result_text=error_message)
        else:
            # Call the extract_features function to extract features from the URL
            features = extract_features(url)

            # Check if features extraction was successful
            if features is None:
                error_message = "Failed to extract features from the provided URL."
            else:
                # Call the predict_phishing function to make a prediction
                prediction = predict_phishing(model, features)

                if prediction is not None:
                    if prediction == 1:
                        result_text = f"your {url} is unssafe"
                    else:
                       result_text = f"your {url} is safe"
                    return render_template("result.html", result_text=result_text, error_message=error_message)

    return render_template("result.html", error_message=error_message)
if __name__=='__main__':
    app.run(debug=True)    